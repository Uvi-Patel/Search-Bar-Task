//
//  Stud+CoreDataProperties.swift
//  Search Bar Task
//
//  Created by MAC on 14/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//
//

import Foundation
import CoreData


extension Stud {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Stud> {
        return NSFetchRequest<Stud>(entityName: "Stud")
    }

    @NSManaged public var name: String?

}
