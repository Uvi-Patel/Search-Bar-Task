//
//  ViewController.swift
//  Search Bar Task
//
//  Created by MAC on 13/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate {
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var searchName: UISearchBar!
    @IBOutlet weak var tblviewName: UITableView!
    
    var arrName:[String] = []
   // var arrFilter:[String] = []
    var search:Bool = false
   var studArray = [Stud]()

    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        searchName.delegate = self
        tblviewName.dataSource = self
        tblviewName.delegate = self
        studArray = DataBaseHelper.shared.getUserData().reversed()
        tblviewName.reloadData()
        
    }
  /* override func viewWillAppear(_ animated: Bool) {
     stud = DataBaseHelper.shared.getUserData()
       tblviewName.reloadData()
   }*/
    @IBAction func ClickToAdd(_ sender: Any) {
        let dict = ["name":txtName.text]
        DataBaseHelper.shared.save(object: dict as [String : Any])
        studArray = DataBaseHelper.shared.getUserData().reversed()
        tblviewName.reloadData()
        txtName.text = nil
        
      /*  if let txt = txtName.text, !txt.isEmpty {
            self.arrName.insert(txt, at: 0)
            tblviewName.reloadData()
            txtName.text = nil
        }*/
    }
    
    @IBAction func clickToDlt(_ sender: Any) {
        print("btn")
        let context = appDelegate.persistentContainer.viewContext
        var index = (sender as AnyObject).tag
        context.delete(studArray[index!] as NSManagedObject)
        studArray.remove(at: index!)
       do {
           try context.save()
        tblviewName.reloadData()
           print("saved!")
       } catch let error as NSError  {
           print("Could not save \(error), \(error.userInfo)")
        }

        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if(search == true){
//            return arrFilter.count
//        }
        return studArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! mycell
        cell.btnDlt.tag = indexPath.row
        cell.btnDlt.addTarget(self, action: #selector(clickToDlt(_:)), for: .touchUpInside)
//        cell.lblName.tag = 5000 + indexPath.row
//        if(search == true){
//            print("\(search)")
//            cell.lblName.text = arrFilter[indexPath.row]
//
//        } else {
//            cell.lblName.text = "\( String(describing: stud[indexPath.row].name ?? ""))"
            cell.lblName.text = (studArray[indexPath.row].name!)
//        }
        
        return cell
    }
  
//    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete{
//            stud = DataBaseHelper.shared.deleteData(index: indexPath.row)
//            tblviewName.deleteRows(at: [indexPath], with: .automatic)
//        }
//    }

    
   func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        print("textDidChange")
        //           filter = arr.filter({$0.lowercased().prefix(searchText.count) == searchText.lowercased()})
//        arrFilter = stud.filter({($0 as AnyObject).localizedCaseInsensitiveContains(searchBar.text!)})
        
     /*   if(arrFilter.count == 0){
            search = false;
            print("if :\(search)")
        }
        else {
            search = true;
        }*/
    if searchText != ""
    {
            var predicate: NSPredicate = NSPredicate()
            predicate = NSPredicate(format: "name contains[c] '\(searchText)'")
    
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
            let context = appDelegate.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"Stud")
            fetchRequest.predicate = predicate
            do {
                studArray = try context.fetch(fetchRequest) as! [Stud]
            } catch let error as NSError {
                print("Could not fetch. \(error)")
            }
    }else{
        studArray = DataBaseHelper.shared.getUserData().reversed()

        //arrFilter.removeAll()
        self.tblviewName.isHidden = false
    }
        
                
       /* if searchText != ""
        {
            if arrFilter.count == 0
            {
                arrFilter.removeAll()
                self.tblviewName.isHidden = true
            }
            
        }
        else{
            
            arrFilter.removeAll()
            self.tblviewName.isHidden = false
        }*/
        
        tblviewName.reloadData()
        
    }
}

class mycell: UITableViewCell{
    
    @IBOutlet weak var lblName: UILabel!

    @IBOutlet weak var btnDlt: UIButton!
}
