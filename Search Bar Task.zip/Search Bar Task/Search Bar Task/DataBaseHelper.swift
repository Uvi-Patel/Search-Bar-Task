//
//  DataBaseHelper.swift
//  Search Bar Task
//
//  Created by MAC on 13/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import Foundation
import CoreData

class DataBaseHelper {
     
    static var shared = DataBaseHelper()
    let context = appDelegate.persistentContainer.viewContext
    
    func save(object: [String:Any]) {

        let userEntrys = NSEntityDescription.insertNewObject(forEntityName: "Stud", into: context) as! Stud
        userEntrys.name = object["name"] as! String
        
        do{
            try context.save()
        } catch {
            print("Data is Not Save")
        }
    }
    
    func getUserData() -> [Stud]{
        
        var stud = [Stud]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Stud")
        
        do{
            stud = try context.fetch(fetchRequest) as! [Stud]
        } catch{
            print("Can not Get Data")
        }
        return stud
    }


//func deleteData(index:Int) -> [Stud]{
//    
//    var Stud1 = getUserData()
//       context.delete(Stud1[index])
//       Stud1.remove(at: index)
//       do{
//           try context.save()
//       } catch {
//           print("Can Not Delete Data")
//       }
//       return Stud1
//   }
}
