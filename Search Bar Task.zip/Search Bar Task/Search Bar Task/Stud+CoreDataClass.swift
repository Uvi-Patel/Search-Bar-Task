//
//  Stud+CoreDataClass.swift
//  Search Bar Task
//
//  Created by MAC on 14/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Stud)
public class Stud: NSManagedObject {

}
